package jamal.consistentHashing;

public class ConsistentHashingSimulator {
}
