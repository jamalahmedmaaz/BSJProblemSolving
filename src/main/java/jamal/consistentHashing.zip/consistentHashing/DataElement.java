package jamal.consistentHashing;

public class DataElement {
    String id;
    String name;

    public DataElement(String record, String name) {
        id = record;
        this.name = name;
    }
}
